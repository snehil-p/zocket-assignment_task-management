package main

import (
	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v4"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"net/http"
	"time"
	"github.com/gorilla/websocket"
)

var db *gorm.DB
var clients = make(map[*websocket.Conn]bool)
var broadcast = make(chan Task)

func initDB() {
	dsn := "host=localhost user=postgres password=password dbname=tasks_db port=5432 sslmode=disable"
	var err error
	db, err = gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		panic("failed to connect database")
	}
	db.AutoMigrate(&User{}, &Task{})
}

type User struct {
	ID       uint   `gorm:"primaryKey"`
	Username string `gorm:"unique"`
	Password string
}

type Task struct {
	ID          uint   `gorm:"primaryKey"`
	Title       string
	Description string
	AssignedTo  uint
	Status      string
}

type Claims struct {
	Username string `json:"username"`
	jwt.RegisteredClaims
}

var jwtKey = []byte("supersecretkey")

func generateToken(username string) (string, error) {
	expirationTime := time.Now().Add(time.Hour * 24)
	claims := &Claims{
		Username: username,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(expirationTime),
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString(jwtKey)
}

func login(c *gin.Context) {
	var user User
	if err := c.ShouldBindJSON(&user); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request"})
		return
	}
	token, _ := generateToken(user.Username)
	c.JSON(http.StatusOK, gin.H{"token": token})
}

func createTask(c *gin.Context) {
	var task Task
	if err := c.ShouldBindJSON(&task); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid task format"})
		return
	}
	db.Create(&task)
	broadcast <- task
	c.JSON(http.StatusOK, task)
}

func handleConnections(c *gin.Context) {
	conn, err := websocket.Upgrade(c.Writer, c.Request, nil, 1024, 1024)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "WebSocket upgrade failed"})
		return
	}
	defer conn.Close()
	clients[conn] = true
	for {
		msg := <-broadcast
		for client := range clients {
			client.WriteJSON(msg)
		}
	}
}

func main() {
	initDB()
	r := gin.Default()
	r.POST("/login", login)
	r.POST("/tasks", createTask)
	r.GET("/ws", handleConnections)
	r.Run(":8080")
}
