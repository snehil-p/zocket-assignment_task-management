import { useState } from "react";
import { useRouter } from "next/router";

export default function Login() {
  const [username, setUsername] = useState("");
  const router = useRouter();

  const handleLogin = async () => {
    const res = await fetch("http://localhost:8080/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username }),
    });
    const data = await res.json();
    localStorage.setItem("token", data.token);
    router.push("/dashboard");
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen">
      <input className="border p-2" type="text" placeholder="Enter username" value={username} onChange={(e) => setUsername(e.target.value)} />
      <button className="mt-2 px-4 py-2 bg-blue-600 text-white rounded" onClick={handleLogin}>
        Login
      </button>
    </div>
  );
}
