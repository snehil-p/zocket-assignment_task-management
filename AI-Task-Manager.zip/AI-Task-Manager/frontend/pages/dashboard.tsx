import { useState, useEffect } from "react";

export default function Dashboard() {
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8080/tasks")
      .then((res) => res.json())
      .then((data) => setTasks(data));
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Task Dashboard</h1>
      <ul>
        {tasks.map((task) => (
          <li key={task.id} className="border p-2 mt-2">{task.title}</li>
        ))}
      </ul>
    </div>
  );
}
